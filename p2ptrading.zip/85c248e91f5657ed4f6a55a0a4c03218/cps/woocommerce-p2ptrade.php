<?php
/*
Plugin Name: WooCommerce p2ptrade Payment Gateway
Description: Платежный шлюз p2ptrade для WooCommerce.
Version: 1.0
Author: Your Name
*/

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Инициализация плагина и платежного шлюза
add_action('plugins_loaded', 'woo_p2ptrade_init');

function woo_p2ptrade_init() {
    if (!class_exists('WC_Payment_Gateway')) return;

    // Основной класс для платежного шлюза
    class WC_Gateway_P2PTrade extends WC_Payment_Gateway {
        public $client_id;
        public $client_secret;
        public $selected_methods;

        // Конструктор класса
public function __construct($method_id = '', $method_details = '') {
    $this->id = 'p2ptrade' . ($method_id ? '_' . $method_id : '');
    $this->method_title = 'p2ptrade' . ($method_details ? ' - ' . $method_details : '');
    $this->method_description = 'Платежный шлюз p2ptrade' . ($method_details ? ' для метода ' . $method_details : '');
    $this->has_fields = true;

    $this->init_form_fields();
    $this->init_settings();

    $this->title = $this->get_option('title', $method_details);
    $this->description = $this->get_option('description', 'Оплата через p2ptrade');
    $this->client_id = get_option('p2ptrade_client_id', '');
    $this->client_secret = get_option('p2ptrade_client_secret', '');
    $this->selected_methods = get_option('p2ptrade_selected_methods', array());

    if (empty($this->client_id) || empty($this->client_secret)) {
        p2ptrade_log("Ошибка: client_id или client_secret не настроены.");
        $this->enabled = 'no'; // Отключаем шлюз, если данные не настроены
    }

    add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
    add_action('woocommerce_api_wc_gateway_p2ptrade', array($this, 'webhook_handler'));
}

        // Инициализация настроек плагина
        public function init_form_fields() {
            // Получаем список валют
            $currencies = $this->get_currencies();
            $currency_options = array();

            if ($currencies && is_array($currencies)) {
                foreach ($currencies as $currency) {
                    $currency_options[$currency['title']] = $currency['name'];
                }
            } else {
                $currency_options['USDT'] = 'USDT'; // Fallback, если API не вернул данные
            }

            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Включить/Выключить',
                    'type' => 'checkbox',
                    'label' => 'Включить этот метод оплаты',
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => 'Название',
                    'type' => 'text',
                    'description' => 'Название платежного метода, которое увидит пользователь',
                    'default' => $this->method_title,
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Описание',
                    'type' => 'textarea',
                    'description' => 'Описание платежного метода, которое увидит пользователь',
                    'default' => 'Оплата через p2ptrade',
                ),
                'callback_url' => array(
                    'title' => 'Callback URL',
                    'type' => 'text',
                    'description' => 'URL для обработки вебхуков от платежного шлюза',
                    'default' => home_url('/wc-api/wc_gateway_p2ptrade'),
                    'desc_tip' => true,
                ),
                'success_url' => array(
                    'title' => 'Success URL',
                    'type' => 'text',
                    'description' => 'URL для перенаправления после успешного платежа',
                    'default' => wc_get_endpoint_url('order-received', '', wc_get_checkout_url()),
                    'desc_tip' => true,
                ),
                'currency' => array(
                    'title' => 'Валюта',
                    'type' => 'select',
                    'description' => 'Выберите валюту для оплаты',
                    'default' => 'USDT',
                    'options' => $currency_options,
                    'desc_tip' => true,
                ),
            );
        }

        // Метод для получения списка валют
        public function get_currencies() {
            p2ptrade_log("Получение списка валют");

            $api_url = 'https://p2ptrade-publicoffice.konomik.com/v1/currencies';

            $headers = array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic SUQtYTM3MGIxN2Q2NmU4NDdhM2JhOGEwYmRmOTdhZmU3N2I1ZjQxZmMxOTE0ZGU0NTE2ODJkZDMxYWJkNWNjYzc2MDoyZjVkYmM1YWEzMDA0OGM3OTQ0NTMwYmQxZDk2MjU3ZjJmMGFiY2RlYWZiNzQxNjhhMGM0YWVhNWRjOTdlZGQ4'
            );

            $response = wp_remote_get($api_url, array(
                'headers' => $headers
            ));

            if (is_wp_error($response)) {
                p2ptrade_log("Ошибка при получении списка валют: " . $response->get_error_message());
                return false;
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            p2ptrade_log("Ответ от API: " . print_r($response_body, true));

            if (isset($response_body['items'])) {
                return $response_body['items'];
            } else {
                p2ptrade_log("Ошибка: список валют не найден в ответе API");
                return false;
            }
        }

        // Получение доступных методов оплаты
        public function get_payment_methods() {
            p2ptrade_log("Получение методов оплаты");

            $api_url = 'https://p2ptrade-publicoffice.konomik.com/v1/exchange/rates?currencyGet=' . $this->get_option('currency', 'USDT') . '&currencyGive=RUB&amount=100';

            $headers = array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic SUQtYTM3MGIxN2Q2NmU4NDdhM2JhOGEwYmRmOTdhZmU3N2I1ZjQxZmMxOTE0ZGU0NTE2ODJkZDMxYWJkNWNjYzc2MDoyZjVkYmM1YWEzMDA0OGM3OTQ0NTMwYmQxZDk2MjU3ZjJmMGFiY2RlYWZiNzQxNjhhMGM0YWVhNWRjOTdlZGQ4'
            );

            $response = wp_remote_get($api_url, array(
                'headers' => $headers
            ));

            if (is_wp_error($response)) {
                p2ptrade_log("Ошибка при получении методов оплаты: " . $response->get_error_message());
                return false;
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            p2ptrade_log("Ответ от API: " . print_r($response_body, true));

            if (isset($response_body['items'][0]['deposits'])) {
                return $response_body['items'][0]['deposits'];
            } else {
                p2ptrade_log("Ошибка: методы оплаты не найдены в ответе API");
                return false;
            }
        }

        // Отображение методов оплаты в процессе оформления заказа
        public function payment_fields() {
            // Убираем отображение выпадающего списка с методами оплаты
            if ($this->description) {
                echo wpautop(wp_kses_post($this->description)); // Выводим только описание платежного метода
            }
        }

        // Обработка платежа
        public function process_payment($order_id) {
            global $woocommerce;
            $order = wc_get_order($order_id);

            // Получаем доступные методы оплаты
            $payment_methods = $this->get_payment_methods();

            if (!$payment_methods || empty($payment_methods)) {
                wc_add_notice('Не удалось получить доступные методы оплаты', 'error');
                return;
            }

            // Используем первый метод оплаты из списка
            $selected_method = $payment_methods[0]['method']; // Первый метод из списка

            // Получение суммы заказа в валюте магазина
            $order_total_store = (float) $order->get_total();

            // Получение валюты магазина
            $store_currency = get_woocommerce_currency();

            // Если валюта магазина не RUB, конвертируем в RUB
            if ($store_currency !== 'RUB') {
                WC()->exchange_rates->refresh();
                $order_total_rub = WC()->exchange_rates->convert($order_total_store, $store_currency, 'RUB');
            } else {
                $order_total_rub = $order_total_store;
            }

            // Получение курса обмена на основе суммы заказа в RUB
            $rate = $this->get_p2ptrade_rate('RUB', $this->get_option('currency', 'USDT'), $order_total_rub);

            if (!$rate) {
                wc_add_notice('Не удалось получить курс обмена', 'error');
                return;
            }

            // Расчет суммы в выбранной валюте
            $order_total_crypto = $order_total_rub / $rate;

            // Подготовка данных для запроса к API
            $data = array(
                'currency' => $this->get_option('currency', 'USDT'),
                'amount' => $order_total_crypto,
                'currencyGive' => 'RUB',
                'method' => $selected_method,
                'callbackUrl' => $this->get_option('callback_url'),
                'successUrl' => $this->get_option('success_url'),
                'failUrl' => $order->get_cancel_order_url(),
                'details' => 'Оплата заказа №' . $order_id,
                'token' => (string) $order_id
            );

            $headers = array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Basic SUQtYTM3MGIxN2Q2NmU4NDdhM2JhOGEwYmRmOTdhZmU3N2I1ZjQxZmMxOTE0ZGU0NTE2ODJkZDMxYWJkNWNjYzc2MDoyZjVkYmM1YWEzMDA0OGM3OTQ0NTMwYmQxZDk2MjU3ZjJmMGFiY2RlYWZiNzQxNjhhMGM0YWVhNWRjOTdlZGQ4'
            );

            $response = wp_remote_post('https://p2ptrade-publicoffice.konomik.com/v1/exchange/orders/deposit', array(
                'method' => 'POST',
                'headers' => $headers,
                'body' => json_encode($data)
            ));

            if (is_wp_error($response)) {
                wc_add_notice('Ошибка при подключении к p2ptrade', 'error');
                p2ptrade_log("Ошибка при подключении к p2ptrade: " . $response->get_error_message());
                return;
            }

            $response_body = json_decode(wp_remote_retrieve_body($response), true);

            if (isset($response_body['result']['success']) && $response_body['result']['success']) {
                // Получаем paymentUrl из ответа API
                $payment_url = $response_body['paymentUrl'];

                // Добавляем выбранный метод оплаты в URL
                $modified_payment_url = str_replace(
                    'https://p2ptrade-payment.konomik.com/',
                    "https://p2ptrade-payment.konomik.com/RUB/{$selected_method}/",
                    $payment_url
                );

                return array(
                    'result' => 'success',
                    'redirect' => $modified_payment_url
                );
            } else {
                $error_message = isset($response_body['errorData']) ? $response_body['errorData'] : 'Неизвестная ошибка';
                wc_add_notice('Ошибка при создании платежа: ' . $error_message, 'error');
                p2ptrade_log("Ошибка при создании платежа: " . $error_message);
            }
        }

        // Получение курса обмена от API
private function get_p2ptrade_rate($currency_give, $currency_get, $amount) {
    p2ptrade_log("Запрос курса обмена: currency_give={$currency_give}, currency_get={$currency_get}, amount={$amount}");

    if ($amount <= 0) {
        p2ptrade_log("Ошибка: Некорректная сумма для расчета курса: " . $amount);
        return false;
    }

    $api_url = 'https://p2ptrade-publicoffice.konomik.com/v1/exchange/rates';
    $query_params = array(
        'currencyGet' => $currency_get,
        'currencyGive' => $currency_give,
        'amount' => $amount,
    );

    $headers = array(
        'Content-Type' => 'application/json',
                'Authorization' => 'Basic SUQtYTM3MGIxN2Q2NmU4NDdhM2JhOGEwYmRmOTdhZmU3N2I1ZjQxZmMxOTE0ZGU0NTE2ODJkZDMxYWJkNWNjYzc2MDoyZjVkYmM1YWEzMDA0OGM3OTQ0NTMwYmQxZDk2MjU3ZjJmMGFiY2RlYWZiNzQxNjhhMGM0YWVhNWRjOTdlZGQ4'
    );

    $response = wp_remote_get($api_url . '?' . http_build_query($query_params), array(
        'headers' => $headers,
    ));

    if (is_wp_error($response)) {
        p2ptrade_log("Ошибка при получении курса: " . $response->get_error_message());
        return false;
    }

    $response_body = json_decode(wp_remote_retrieve_body($response), true);

    p2ptrade_log("Ответ от API: " . print_r($response_body, true));

    if (isset($response_body['result']['error'])) {
        p2ptrade_log("Ошибка API: " . $response_body['result']['error']);
        return false;
    }

    if (isset($response_body['items'][0]['deposits'][0]['rate'])) {
        return $response_body['items'][0]['deposits'][0]['rate'];
    } else {
        p2ptrade_log("Ошибка: курс не найден в ответе API");
        return false;
    }
}

        // Обработка вебхука
        public function webhook_handler() {
            // Получаем входящие данные
            $raw_post_data = file_get_contents('php://input');
            $headers = getallheaders();

            // Логируем входящие данные
            p2ptrade_log("Входящий webhook. Данные: " . $raw_post_data);
            p2ptrade_log("Заголовки запроса: " . json_encode($headers));

            // Декодируем JSON
            $data = json_decode($raw_post_data, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                p2ptrade_log("Ошибка декодирования JSON: " . json_last_error_msg());
                http_response_code(400);
                die('Invalid JSON');
            }

            // Проверяем обязательные поля
            $required_fields = ['OrderId', 'Status', 'Token', 'Amount', 'Currency'];
            foreach ($required_fields as $field) {
                if (!isset($data[$field])) {
                    p2ptrade_log("Ошибка: Отсутствует обязательное поле {$field}");
                    http_response_code(400);
                    die("Missing required field: {$field}");
                }
            }

            // Получаем заказ
            $order = wc_get_order($data['Token']);
            if (!$order) {
                p2ptrade_log("Ошибка: Заказ не найден. Token: " . $data['Token']);
                http_response_code(404);
                die('Order Not Found');
            }

            // Сохраняем дополнительные данные в метаданных заказа
            $order->update_meta_data('p2ptrade_order_id', $data['OrderId']);
            $order->update_meta_data('p2ptrade_amount_received', $data['Amount']);
            $order->update_meta_data('p2ptrade_currency_received', $data['Currency']);
            $order->update_meta_data('p2ptrade_amount_paid', $data['PayAmount'] ?? 'Не указана');
            $order->update_meta_data('p2ptrade_currency_paid', $data['PayCurrency'] ?? 'Не указана');

            // Логика обработки статуса "Expired"
            if ($data['Status'] == 'Expired') {
                $order->update_status('cancelled');
                $order->add_order_note('P2PTrade: Заказ отменен, время истекло');
                p2ptrade_log("Статус заказа {$data['Token']} обновлен на cancelled (время истекло).");
            }

            // Приоритет статусов
            $status_priority = [
                'cancelled' => 0,
                'failed' => 1,
                'pending' => 2,
                'on-hold' => 3,
                'processing' => 4,
                'completed' => 5,
            ];

            $current_status = $order->get_status();
            $new_status = strtolower($data['Status']);
            $current_priority = $status_priority[$current_status] ?? 0;
            $new_priority = $status_priority[$new_status] ?? 0;

            if ($new_priority > $current_priority) {
                switch ($new_status) {
                    case 'checking':
                        $order->update_status('pending');
                        $order->add_order_note('P2PTrade: Проверка платежа');
                        break;

                    case 'depositawaiting':
                        $order->update_status('pending');
                        $order->add_order_note('P2PTrade: Ожидание оплаты');
                        break;

                    case 'depositconfirmation':
                        $order->update_status('on-hold');
                        $order->add_order_note('P2PTrade: Платеж отправлен, ожидается подтверждение');
                        break;

                    case 'confirmed':
                        $order->update_status('processing');
                        $order->add_order_note('P2PTrade: Платеж подтвержден.');
                        break;

                    case 'completed':
                        if (!$order->is_paid()) {
                            $order->payment_complete($data['OrderId']);
                            $order->add_order_note(sprintf(
                                'P2PTrade: Оплата подтверждена. Получено: %s %s (Оплачено: %s %s)',
                                $data['Amount'],
                                $data['Currency'],
                                $data['PayAmount'] ?? 'Не указана',
                                $data['PayCurrency'] ?? 'Не указана'
                            ));
                        }
                        break;

                    case 'failed':
                        $order->update_status('failed');
                        $order->add_order_note('P2PTrade: Оплата не прошла');
                        break;

                    case 'cancelled':
                        $order->update_status('cancelled');
                        $order->add_order_note('P2PTrade: Заказ отменен');
                        break;

                    case 'dispute':
                        $order->update_status('on-hold');
                        $order->add_order_note('P2PTrade: Открыт спор по заказу');
                        break;

                    default:
                        $order->add_order_note('P2PTrade: Получен неизвестный статус: ' . $data['Status']);
                        p2ptrade_log("Получен неизвестный статус для заказа {$data['Token']}: " . $data['Status']);
                }
            } else {
                p2ptrade_log("Статус заказа {$data['Token']} не обновлен: текущий статус {$current_status} имеет более высокий или равный приоритет.");
            }

            $order->save();

            // Отправляем успешный ответ
            http_response_code(200);
            die('OK');
        }
    }

    // Динамически добавляем платежные методы
    add_filter('woocommerce_payment_gateways', 'add_p2ptrade_gateways_conditionally');

    function add_p2ptrade_gateways_conditionally($methods) {
        $selected_methods = get_option('p2ptrade_selected_methods', array());

        if (!empty($selected_methods)) {
            foreach ($selected_methods as $method_id => $method_details) {
                $methods[] = new WC_Gateway_P2PTrade($method_id, $method_details);
            }
        }

        return $methods;
    }
}

// Добавление меню в админке WordPress
add_action('admin_menu', 'p2ptrade_admin_menu');

function p2ptrade_admin_menu() {
    add_menu_page(
        'P2PTrade', // Заголовок страницы
        'P2PTrade', // Название меню
        'manage_options', // Права доступа
        'p2ptrade-settings', // Слаг страницы
        'p2ptrade_settings_page', // Функция для отображения страницы
        'dashicons-money', // Иконка
        56 // Позиция в меню
    );
}

// Отображение страницы настроек P2PTrade
function p2ptrade_settings_page() {
    if (isset($_POST['p2ptrade_save_settings'])) {
        $selected_methods = isset($_POST['selected_methods']) ? $_POST['selected_methods'] : array();
        update_option('p2ptrade_selected_methods', $selected_methods);

        // Сохранение Client ID и Client Secret
        if (isset($_POST['client_id'])) {
            update_option('p2ptrade_client_id', sanitize_text_field($_POST['client_id']));
        }
        if (isset($_POST['client_secret'])) {
            update_option('p2ptrade_client_secret', sanitize_text_field($_POST['client_secret']));
        }

        // Сохранение Callback URL и Success URL
        if (isset($_POST['callback_url'])) {
            update_option('woocommerce_p2ptrade_callback_url', sanitize_text_field($_POST['callback_url']));
        }
        if (isset($_POST['success_url'])) {
            update_option('woocommerce_p2ptrade_success_url', sanitize_text_field($_POST['success_url']));
        }

        // Сохранение выбранной валюты
        if (isset($_POST['currency'])) {
            update_option('woocommerce_p2ptrade_currency', sanitize_text_field($_POST['currency']));
        }

        echo '<div class="updated"><p>Настройки сохранены!</p></div>';
    }

    // Получаем сохраненные значения
    $client_id = get_option('p2ptrade_client_id', '');
    $client_secret = get_option('p2ptrade_client_secret', '');
    $callback_url = get_option('woocommerce_p2ptrade_callback_url', home_url('/wc-api/wc_gateway_p2ptrade'));
    $success_url = get_option('woocommerce_p2ptrade_success_url', wc_get_endpoint_url('order-received', '', wc_get_checkout_url()));
    $currency = get_option('woocommerce_p2ptrade_currency', 'USDT');

    // Создаем экземпляр класса WC_Gateway_P2PTrade
    $gateway = new WC_Gateway_P2PTrade();

    // Получаем доступные методы оплаты
    $methods = $gateway->get_payment_methods();

    // Получаем список валют
    $currencies = $gateway->get_currencies();

    echo '<div class="wrap">';
    echo '<h1>Настройки P2PTrade</h1>';
    echo '<form method="post" action="">';
    echo '<table class="form-table">';
    echo '<tr valign="top">';
    echo '<th scope="row">Client ID</th>';
    echo '<td><input type="text" name="client_id" value="' . esc_attr($client_id) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Client Secret</th>';
    echo '<td><input type="text" name="client_secret" value="' . esc_attr($client_secret) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Callback URL</th>';
    echo '<td><input type="text" name="callback_url" value="' . esc_attr($callback_url) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Success URL</th>';
    echo '<td><input type="text" name="success_url" value="' . esc_attr($success_url) . '" class="regular-text"></td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Валюта</th>';
    echo '<td>
            <select name="currency" class="regular-text">';
    if ($currencies && is_array($currencies)) {
        foreach ($currencies as $currency_item) {
            echo '<option value="' . esc_attr($currency_item['title']) . '"' . selected($currency, $currency_item['title'], false) . '>' . esc_html($currency_item['name']) . '</option>';
        }
    } else {
        echo '<option value="USDT"' . selected($currency, 'USDT', false) . '>USDT</option>';
    }
    echo '</select>
          </td>';
    echo '</tr>';
    echo '<tr valign="top">';
    echo '<th scope="row">Доступные методы оплаты</th>';
    echo '<td>';

    if ($methods && is_array($methods)) {
        foreach ($methods as $method) {
            $checked = in_array($method['method'], get_option('p2ptrade_selected_methods', array())) ? 'checked' : '';
            echo '<label><input type="checkbox" name="selected_methods[]" value="' . esc_attr($method['method']) . '" ' . $checked . '> ' . esc_html($method['details']) . '</label><br>';
        }
    } else {
        echo 'Методы оплаты не найдены.';
    }

    echo '</td>';
    echo '</tr>';
    echo '</table>';
    echo '<p class="submit"><input type="submit" name="p2ptrade_save_settings" class="button-primary" value="Сохранить изменения"></p>';
    echo '</form>';
    echo '</div>';
}

// Функция для логирования в debug.log
function p2ptrade_log($message) {
    if (is_array($message) || is_object($message)) {
        $message = json_encode($message, JSON_PRETTY_PRINT);
    }

    $timestamp = date("Y-m-d H:i:s");

    if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
        error_log("[" . $timestamp . "] P2PTrade: " . str_replace("\n", " ", $message));
    }
}